#pragma once

#define HTTP_SERVER "141.98.6.110"
#define HTTP_PORT 80

#define TFTP_SERVER "141.98.6.110"
